<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }

    include 'imports/dbSettings.php';
    
    $artikelID="";
    $menge="";

    $artikelID= $_POST['artikelID'];
    $menge= $_POST['amount'];



try{

$sql = "INSERT INTO warenkorb (ArtikelID,UserID,Menge) VALUES (?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->execute([$artikelID,$userID,$menge]);

} catch(PDOException $f){
echo "Fehler: ".$f;
}
header("Location: alleArtikel.php");
?>