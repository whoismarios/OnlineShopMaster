<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }

    include 'imports/dbSettings.php';
    
    $artikelID="";
    $menge="";

    $artikelID= $_POST['artikelID'];
    $menge= $_POST['amount'];



try{

$sql = "";//Hier UPdateBefehl für DB sth like UPDATE Warenkorb SET amount VALUES(?) WHERE ArtikelID = ? AND UserID = ?
$stmt = $conn->prepare($sql);
$stmt->execute([$artikelID,$userID,$menge]);

} catch(PDOException $f){
echo "Fehler: ".$f;
}
header("Location: alleArtikel.php");
?>