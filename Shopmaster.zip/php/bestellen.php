<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }

    include 'imports/dbSettings.php';
    
    $PositionsPreis=0;
    $versandpreis=0;
    $versandart=0;
    $versandart=$_POST["Versandart"];

try{

$sql = "SELECT * FROM Warenkorb WHERE UserID='" . $userID . "' ";

$ExecQuery = MySQLi_query($con,$sql);
if(mysqli_num_rows($ExecQuery) > 0) {

    $Gesamtpreis=0;

$alles= "SELECT * FROM Warenkorb AS W LEFT JOIN Artikel AS A  ON W.ARtikelID=A.ArtikelID";

    $gpmitRabatt=0;


foreach($conn->query($alles) as $row){
    if($row['Menge'] >= 5)
    {
    $rabattanz="10 %";
    $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.9),2);
    }
    
    if($row['Menge'] < 5 )
    {
    $rabattanz="0 %";
    $gpmitRabatt=round(($row['preis'] * $row['Menge']),2);
    }

    if($row['Menge'] >= 10)
    {
    $rabattanz="20 %";   
    $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.8),2);
    }
    $Gesamtpreis=$Gesamtpreis +$gpmitRabatt;

}
}
/*
foreach($conn->query($sql) as $row){
    
}
*/
if($versandart=="DHL"){
    $versandpreis=15;
}
if($versandart=="DPD"){
    $versandpreis=6;
}
if($versandart=="DHL Express"){
    $versandpreis=48;
}





$insert= "INSERT INTO Bestellung (Gesamtpreis,UserID,Versandpreis,Versandart) VALUES (?,?,?,?)";
$stmt= $conn->prepare($insert);
$stmt-> execute([$Gesamtpreis,$userID,$versandpreis,$versandart]);


$krasserBefehl= "SELECT *
FROM bestellung
WHERE UserID=' " . $userID . " ' AND Gesamtpreis=" . $Gesamtpreis.  " AND BestellID>=(SELECT MAX(BestellID) FROM Bestellung)";
$bestellID=0;
foreach($conn->query($krasserBefehl) as $row){
    $bestellID=$row['BestellID'];
}


$sql = "SELECT * FROM Warenkorb WHERE UserID='" . $userID . "' ";

$ExecQuery = MySQLi_query($con,$sql);
if(mysqli_num_rows($ExecQuery) > 0) {

    $Gesamtpreis=0;

$alles= "SELECT * FROM Warenkorb AS W LEFT JOIN Artikel AS A  ON W.ARtikelID=A.ArtikelID";

    $gpmitRabatt=0;


foreach($conn->query($alles) as $row){
    if($row['Menge'] >= 5)
    {
    $rabattanz="10 %";
    $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.9),2);
    }
    
    if($row['Menge'] < 5 )
    {
    $rabattanz="0 %";
    $gpmitRabatt=round(($row['preis'] * $row['Menge']),2);
    }

    if($row['Menge'] >= 10)
    {
    $rabattanz="20 %";   
    $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.8),2);
    }
    
    
        $insert2= "INSERT INTO bestellitem (BestellID,ArtikelID,Menge,PositionsPreis) VALUES (?,?,?,?)";
        $stmt2= $conn->prepare($insert2);
        $stmt2-> execute([$bestellID,$row['ArtikelID'],$row['Menge'],$gpmitRabatt]);
        
    

}
}
$delete="DELETE FROM Warenkorb WHERE UserID = '".$userID."'";
$stmt3= $conn-> prepare($delete);
$stmt3->execute();






} catch(PDOException $f){
echo "Fehler: ".$f;
}
header("Location: thx.php");

?>