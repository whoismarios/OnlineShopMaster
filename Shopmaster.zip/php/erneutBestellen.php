<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }

    include 'imports/dbSettings.php';

    $bestellID=$_POST["BestellID"];
    
    $sql ="SELECT * 
    FROM kunde, bestellitem AS BI ,bestellung AS B 
    WHERE B.BestellID=bi.bestellid 
    AND kunde.UserID = '" . $userID . "'
    AND B.UserID = Kunde.UserID; "

    
?>
